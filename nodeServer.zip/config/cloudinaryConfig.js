const cloudinary = require('cloudinary')
cloudinary.config({
  cloud_name: "smartfarming",
  api_key: "649517584425433",
  api_secret: "DZ_3lZl1lVQ2nYvcKCpVK67mSWQ"
})